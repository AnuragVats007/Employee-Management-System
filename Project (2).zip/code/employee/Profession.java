package employee;


public enum Profession {
    INVALID, // Not allowed profession
    SECRETARY,
    TECHNICIAN,
    PROGRAMMER
}
