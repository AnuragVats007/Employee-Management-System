package employee;

public enum Gender {
    MAN,
    WOMAN,
    UNDEFINED
}
